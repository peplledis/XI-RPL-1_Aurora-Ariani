<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style2.css">
    <title>Aurora's Profile</title>
</head>
<body>
    
    <div class="container">
        <div class="sidebar">
            <div class="header">
                <div class="list-item">
                    <a href="profile.php">
                        <img class="icon" src="img/User.svg" alt="icon user">
                        <span class="desc-header">Aurora Ariani</span>
                    </a>
                </div>
                <div class="ilustrasi">
                    <img src="img/10586 1.svg" alt="ilustrasi">
                </div>
            </div>
            <div class="main">
                <div class="list-item">
                    <a href="#">
                        <img class="icon" src="img/Frame 1.svg" alt="">
                        <span class="desc">Dashbord</span>
                    </a>
                </div>
                <div class="list-item">
                    <a href="#">
                        <img class="icon" src="img/Frame 1 (1).svg" alt="">
                        <span class="desc">Analytics</span>
                    </a>
                </div>
                <div class="list-item">
                    <a href="#">
                        <img class="icon" src="img/Frame 1 (2).svg" alt="">
                        <span class="desc">Category</span>
                    </a>
                </div>
                <div class="list-item">
                    <a href="#">
                        <img class="icon" src="img/Frame 1 (3).svg" alt="">
                        <span class="desc">Team</span>
                    </a>
                </div>
                <div class="list-item">
                    <a href="#">
                        <img class="icon" src="img/Frame 1 (4).svg" alt="">
                        <span class="desc">Event</span>
                    </a>
                </div>
                <div class="list-item">
                    <a href="#">
                        <img class="icon" src="img/Frame 1 (5).svg" alt="">
                        <span class="desc">Explore</span>
                    </a>
                </div>
                <div class="list-item">
                    <a href="#">
                        <img class="icon" src="img/Frame 1 (6).svg" alt="">
                        <span class="desc">History</span>
                    </a>
                </div>
                <div class="list-item">
                    <a href="#">
                        <img class="icon" src="img/Frame 1 (7).svg" alt="">
                        <span class="desc">Setting</span>
                    </a>
                </div>
        </div class="main-content">
            <div id="menu-button">
                <input type="checkbox" id="menu-checkbox">
                <label for="menu-checkbox"></label>
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>