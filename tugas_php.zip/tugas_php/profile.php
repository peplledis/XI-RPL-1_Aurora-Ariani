<?php
    $nama = "Aurora Ariani swifties Murphy";
    $umur = "16 years old";
    $ultah = "April 21st";
    $sekolah = "SMKN 2 Bandung";
    $cita_cita = "Become a billionaire";
    $foto = "img/hermione.jpg";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <title>Aurora's Profile</title>
</head>
<body>
    <div class="card">
        <img src="<?php echo $foto; ?>" alt="Foto Profil Aurora">
        <div>
            <div class="chip">
                <?php echo $nama; ?>
            </div>
            <div class="desc">
                <p>Age: <?php echo $umur; ?></p>
                <p>BIrthday: <?php echo $ultah; ?></p>
                <p>School: <?php echo $sekolah; ?></p>
                <p>Dream: <?php echo $cita_cita; ?></p>
            </div>
            <button>contact</button>
        </div>
    </div>
</body>
</html>
